/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/

//view initializer
function init_adminView(){
    
}

init_adminView();

/* Controller function Library*/

