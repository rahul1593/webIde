/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/
//controller data

//view initializer
function init_mangerView(){
    
}

init_managerView();

/* Controller function Library*/

