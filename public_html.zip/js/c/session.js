/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/
/*
 * Assume js/m/lib.js ans js/appfm/core.js to be loaded
 */
rootObj = twf.__cdata.appBodyObj;
//controller data
usrObj = null;
pswdObj = null;
//view initializer
function init_loginView(){
    rootObj.align = 'middle';
    var pDiv = getPropMappedElement('div',{style:"position:relative;top:50%;transform:translateY(-50%);width:300px;height:200px;"});
    rootObj.appendChild(pDiv);
    var html = '<div style="position:absolute;top:50%;transform:translateY(-80%);font-size:12px;color:#222222">\
            <div style="display:table-row">\
                <pre style="display:inline">Username : </pre>\
                <input id="username" class="textInput" type="text" value="" placeholder="here you go" style="width:150px"/>\
            </div><br>\
            <div style="display:table-row">\
                <pre style="display:inline">Password : </pre>\
                <input id="password" class="textInput" type="password" value="" placeholder="it\'s secret" style="width:150px"/>\
            </div><br>\
            <div align="right">\
                <input id="lgnButton" class="textInput button" type="submit" value="Login" onclick="onLogin()"/>&nbsp;\
                <input id="clrButton" class="textInput button" type="submit" value="Cancel" onclick="onCancel()"/>\
            </div>\
        </div>';
     pDiv.innerHTML = html;
     usrObj = document.getElementById('username');
     pswdObj = document.getElementById('password');
     usrObj.focus();
     window.addEventListener('keypress',function(e){keyDown(e);}, false);
}

function clearView(){
    
}

init_loginView();

/* Controller function Library*/

function keyDown(e){
    var evt = window.event || e ||event;
    if(evt.charCode === 13){
        onLogin();
    }
}

function validateInputs(){
    if(usrObj.value.length<5 ||usrObj.value.length>30){
        alert('Invalid Username: length must be between 5 and 30 characters.');
        return false;
    }else{
        if(pswdObj.value.length<5 ||pswdObj.value.length>30){
            alert('Invalid Password: length must be in between 5 and 30 characters.');
            return false;
        }
    }
    return true;
}

function onLogin(){
    if(!validateInputs()){
        return;
    }
    alert('check');
}

function onCancel(){
    usrObj.value = "";
    pswdObj.value = "";
}

