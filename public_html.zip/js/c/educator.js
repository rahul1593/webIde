/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/
//controller data

//view initializer
function init_educatorView(){
    
}

init_educatorView();

/* Controller function Library*/

