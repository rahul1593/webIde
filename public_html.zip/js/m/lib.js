/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/
/*
 * This function creates an element and maps all the supplied attributes as an object.
 * tag: html tag name
 * attrs: object containing attributes for the object to be created
 */
function getPropMappedElement(tag, attrs){
    var elm = document.createElement(tag);
    for(var prop in attrs){
        elm[prop] = attrs[prop];
    }return elm;
}
