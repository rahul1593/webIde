/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/

twf = {
    __cdata:{
        username: null,
        role: 'educator',   //loaded after login
        viewId: 'init',     //one of these [login, edu_dshb, edu_perf, edu_tsk_chon, edu_tsk_cobj, edu_tsk_rhon, edu_tsk_robj, ....]
        appBodyObj: null
    },
    model:{
        __data:{
            services: []
        },
        service: function(handler){
            var callback = handler;
            var state = 'stopped';         //running
            var timerObj = null;
            this.start = function(ms){
                if(callback === null){
                    return false;
                }
                timerObj = setInterval(callback, ms);
                state = 'running';
                return true;
            };
            this.setInterval = function(ms){
                if(timerObj === null){
                    return false;
                }
                clearInterval(timerObj);
                timerObj = setInterval(callback, ms);
                return true;
            };
            this.stop = function(){
                if(timerObj === null){
                    return false;
                }
                clearInterval(timerObj);
                state = 'stopped';
            };
            this.getState = function(){
                return state;
            };
        }
    },
    controller:{
        control: {
        },
        bind: function(view, controller_src){   //view can be one single or a list of views
            if(typeof view !== 'string'){
                for(var val in view){
                    twf.controller.control[view[val]] = controller_src;
                }
                return;
            }
            twf.controller.control[view] = controller_src;
        },
        getControllerSrc: function(view){
            return twf.controller.control[view];
        }
    },
    view:{      //only one view is loaded at a time
        objects:{
            header: function(object){
                var obj = object;
                var titleObj = document.createElement('span');
                var wcMessageObj = document.createElement('span');
                var menuObj = document.createElement('ul');
                var menuItemObjs = [];
                
                obj.appendChild(titleObj);
                titleObj.innerHTML = 'Change Title';
                titleObj.style = 'position:absolute;left:1%;bottom:5%;font-size:18px;font-weight:bold;color:white';
                
                obj.appendChild(wcMessageObj);
                wcMessageObj.innerHTML = 'Welcome Guest';
                wcMessageObj.style = 'position:absolute;right:10%;bottom:5%;font-size:12px;font-weight:bold;color:white';
                
                obj.appendChild(menuObj);
                menuObj.className = 'menu';
                menuObj.align = 'left';
                
                this.getTitle = function(){return titleObj.innerHTML;};
                this.setTitle = function(text){
                    titleObj.innerHTML = text;
                };
                this.setWelcomMessage = function(msg){
                    wcMessageObj.innerHTML = msg;
                };
                this.addMenuItem = function(itemText, action){
                    var itm = document.createElement('li');
                    itm.className = 'menuItem';
                    itm.name = itemText;
                    var tmp = document.createElement('span');
                    itm.appendChild(tmp);
                    tmp.innerHTML = itemText;
                    menuObj.appendChild(itm);
                    if(action === null){
                        return null;
                    }
                    menuItemObjs[menuItemObjs.length] = itm;
                    tmp.addEventListener('click', action, false);
                    return itm;
                };
                function searchMenuItem(txt){
                    for(var i=0;i<menuItemObjs.length;i++){
                        if(menuItemObjs[i].name === txt){
                            return i;
                        }
                    }
                    return -i;
                }
                this.removeMenuItem = function(itemText){
                    var indx = searchMenuItem(itemText);
                    if(indx<0){
                        return false;
                    }
                    menuObj.removeChild(menuItemObjs[indx]);
                    menuItemObjs.splice(indx,1);
                    return true;
                };
                this.addContextItem = function(itemName, contextItemText, action){
                    var indx = searchMenuItem(itemName);
                    if(indx<0){
                        return false;
                    }
                    var pItm = menuItemObjs[indx];
                    var cont = pItm.getElementsByClassName('contextMenu');
                    if(cont.length<1){
                        cont = document.createElement('div');
                        cont.className = 'contextMenu';
                        pItm.appendChild(cont);
                    }else{
                        cont = cont[0];
                    }
                    var cxitm = document.createElement('z');
                    cxitm.className = 'contextMenuItem';
                    cxitm.innerHTML = contextItemText;
                    cxitm.addEventListener('click', action, false);
                    cont.appendChild(cxitm);
                    return cxitm;
                }
            },
            footer: function(object) {
                var obj = object;
                var cpNoticeObj = document.createElement('span');
                
                obj.appendChild(cpNoticeObj);
                cpNoticeObj.innerHTML = 'Change Notice';
                cpNoticeObj.style = 'position:absolute;left:45%;bottom:5%;font-size:12px;color:white';
                
                this.setNotice = function(text){
                    cpNoticeObj.innerHTML = text;
                };
            }
        },
        __data:{
            header: null,
            footer: null,
            body: null,
            data: null,
            controller: null    //script object holding the controller js script
        },
        loadView: function(viewId){
            twf.__cdata.viewId = viewId;
            //load controller
            var control_scr = document.createElement('script');
            if(twf.view.__data.controller !== null){
                twf.view.__data.data.removeChild(twf.view.__data.controller);
            }
            control_scr.src = twf.controller.control[viewId];
            twf.view.__data.data.appendChild(control_scr);
        }
    },
    init: function(rootWinObj){
        var tmp = document.createElement('div');
        tmp.className = 'header';
        twf.view.__data.header = new twf.view.objects.header(tmp);
        rootWinObj.appendChild(tmp);
        
        twf.view.__data.body = document.createElement('div');
        twf.view.__data.body.className = 'appBody';
        rootWinObj.appendChild(twf.view.__data.body);
        twf.__cdata.appBodyObj = twf.view.__data.body;
        
        var tmp = document.createElement('div');
        twf.view.__data.footer = new twf.view.objects.footer(tmp);
        tmp.className = 'footer';
        rootWinObj.appendChild(tmp);
        
        twf.view.__data.data = document.createElement('div');
        twf.view.__data.data.name = 'tfw_data';
        rootWinObj.appendChild(twf.view.__data.data);
    }
};