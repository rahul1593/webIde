/* 
    Created on : 22 Jan, 2017, 4:04:06 PM
    Author     : geek
*/
//initialize the default UI by framework
twf.init(document.getElementsByTagName('body')[0]);

var hd = twf.view.__data.header;
hd.setTitle('Team Work');
/*
hd.addMenuItem('Dashboard', function(){alert("Waht?? dashboard !!");});
hd.addMenuItem('Performance', function(){alert("Waht?? performance !!");});
hd.addMenuItem('Tasks', function(){alert("Waht?? tasks !!");});
hd.addContextItem('Tasks', 'Create', function(){alert('Context Item !!');});
hd.addContextItem('Tasks', 'Review', function(){alert('Context Item !!');});

hd.addMenuItem('Help', function(){alert("Waht?? help !!");});
hd.addContextItem('Help', 'Content', function(){alert('Context Item !!');});
hd.addContextItem('Help', 'Report Issue', function(){alert('Context Item !!');});
hd.addContextItem('Help', 'About', function(){alert('Context Item !!');});

hd.addMenuItem('Logout', function(){alert("Waht?? logout !!");});
*/
/*
 * All the possible different layout states are:
 * log, edu_dshbd, edu_report, edu_help, 
 */
twf.controller.bind('log', 'js/c/session.js');
twf.controller.bind(['edu_dshb', 'edu_report', 'edu_crt_obj', 'edu_crt_hon', 'edu_rvw_obj', 'edu_rvw_hon', 'edu_cst_tsk', 'edu_help'], 'js/c/educator.js');
twf.controller.bind(['mgr_dshb', 'mgr_report', 'mgr_crt_tsk', 'mgr_set_tgt', 'mgr_help'], 'js/c/manager.js');
twf.view.__data.footer.setNotice('Infosys pvt.ltd');

twf.view.loadView('log');