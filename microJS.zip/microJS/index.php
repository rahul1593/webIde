<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel='stylesheet' type='text/css' href="css/ide.css">
        <link rel='stylesheet' type='text/css' href="css/fontello.css">
        <script type='text/javascript' src="js/f/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="js/f/micro.js"></script>
        <title>Web IDE</title>
    </head>
    <body>
        <script type="text/javascript" src="js/v/ide_init.js"></script>
    </body>
</html>
